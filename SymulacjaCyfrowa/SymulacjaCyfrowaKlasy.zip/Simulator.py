from Event import Event
from GenerateEvent import GenerateEvent
from ReportEvent import ReportEvent
from Network import Network 
import numpy as np

class Simulator:

  eventList = []
  clock = 0
  network = Network()

  def mainLoop(self):

    executionTime = 5 + 30 * np.random.uniform() #np.random.exponential() potem
    self.eventList.append(GenerateEvent(self.network, executionTime))
    self.eventList.sort(reverse=True, key = Event.getExecutionTime)

    while self.clock <= 20:
      #wrzuć nowy even do listy (zaplanuj)
      print("Clock: " + str(self.clock) + " User length: " + str(self.network.userListLength()))
      self.clock = self.clock + 1
      print(self.eventList[-1].getExecutionTime())

      #execute eventu z najmniejszym czasem i wywal go w pętli aż nie będzie ujemnych
      while self.eventList[-1].getExecutionTime() < 0:
        if self.eventList[-1].execute():      #GenerateEvent returns true; ReportEvent returns false
          executionTime = 5 + 30 * np.random.uniform() #np.random.exponential() potem
          self.eventList.append(GenerateEvent(self.network, executionTime))
          self.eventList.sort(reverse=True, key = Event.getExecutionTime)
        self.eventList.pop(-1)

      #czas--
      for event in self.eventList:
        event.updateTime(3)