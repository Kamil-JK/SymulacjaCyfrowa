class User:

    def __init__(self, speed, position):
        print("User created with speed: " + str(speed))
        self.speed = speed
        self.position = position