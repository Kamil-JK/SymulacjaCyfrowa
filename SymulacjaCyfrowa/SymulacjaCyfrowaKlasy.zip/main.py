from Simulator import Simulator 

simulator = Simulator()
simulator.mainLoop()